classdef MpcControl_lon < MpcControlBase
    
    methods
        % Design a YALMIP optimizer object that takes a steady-state state
        % and input (xs, us) and returns a control input
        function ctrl_opti = setup_controller(mpc)
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % INPUTS
            %   x0           - initial state (estimate)
            %   x_ref, u_ref - reference state/input
            % OUTPUTS
            %   u0           - input to apply to the system
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            N_segs = ceil(mpc.H/mpc.Ts); % Horizon steps
            N = N_segs + 1;              % Last index in 1-based Matlab indexing

            [nx, nu] = size(mpc.B);
            
            % Targets
            x_ref = sdpvar(nx, 1); % shape = (2, 1)
            u_ref = sdpvar(nu, 1); % shape = (1, 1)

            % Disturbance estimate (Ignore this before Todo 4.1)
            d_est = sdpvar(1);

            % Initial states
            x0 = sdpvar(nx, 1);
            x0other = sdpvar(nx, 1); %Lead car initial state

            % Input to apply to the system
            u0 = sdpvar(nu, 1);
            
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % YOUR CODE HERE YOUR CODE HERE YOUR CODE HERE YOUR CODE HERE
            
            % NOTE: The matrices mpc.A, mpc.B, mpc.C and mpc.D
            %       are the DISCRETE-TIME MODEL of your system
            %       You can find the linearization steady-state
            %       in mpc.xs and mpc.us.
            %Loading Pre-Computed things:
            data = load('tube_mpc_data.mat'); 
            E = data.sets.E; 
            K1 = data.sets.K;      
            
            %Delta Dynamics:
            Delta_x = sdpvar(2, N);    
            Delta_u = sdpvar(1, N-1); 
            
            %Constraints: 
            M = [1;-1]; m = [1; 1]; %input constraints
            % x in X = { x | Fx <= f }Safety constraint
            F = [1 0; 0 0; 0 0; 0 0]; f = [6; 0; 0; 0]; % x_ego - x_lead < -6 
            
            % Compute tightened state constraints X_t
            h_E_F = zeros(size(F, 1), 1); % Support function h_E(F)
            for i = 1:size(F, 1)
                h_E_F(i) = max(F(i, :) * E.V');
            end
            f_t = f - h_E_F; % Tightened RHS
            X_t = Polyhedron('A', F, 'b', f_t);

            % Compute tightened input constraints U_t
            h_KE_M = zeros(size(M, 1), 1); % Support function h_{KE}(M)
            for i = 1:size(M, 1)
                h_KE_M(i) = max(M(i, :) * (K1 * E.V'));
            end
            m_t = m - h_KE_M; % Tightened RHS
            U_t = Polyhedron('A', M, 'b', m_t);

            % Verify origin containment
            if X_t.contains([0; 0])
                disp('X_t contains the origin.');
            else
                warning('X_t does NOT contain the origin.');
            end
            
            % Define weighting matrices for cost
            Q = diag([10, 10]); 
            R = 1;   
            % Compute terminal components
            % Terminal Cost and Feedback Gain (LQR-based terminal components)
            [P, K, ~] = dare(mpc.A, mpc.B, Q, R); % Terminal cost P and feedback gain K
            K = -K'; % MATLAB returns -K, invert sign for consistency

            % Compute Terminal Set X_f under tightened constraints
            Acl = mpc.A - mpc.B * K; 
           
            eig_Acl = eig(Acl);
            if any(abs(eig_Acl) >= 1)
                fprintf('Closed-loop system is not stable. Eigenvalues:\n');
                disp(eig_Acl);
            end

            Xf = Polyhedron('A', F, 'b', f_t); % Initial terminal set from tightened constraints
            
            % Set iteration limit for terminal set computation
            max_iter = 100; 
            iter = 0;

            % Visualize the progress of the terminal set computation
            figure;
            hold on;
            title('Terminal Set Convergence');
            xlabel('X1');
            ylabel('X2');

            % Iterative computation of the terminal set
            while true
                iter = iter + 1;
                prevXf = Xf;

                % Compute pre-set
                T = Xf.A; 
                t = Xf.b;
                preXf = Polyhedron('A', T * Acl, 'b', t);

                % Intersect with the current terminal set
                Xf = intersect(Xf, preXf);

                % Plot the current terminal set
                plot(Xf, 'Color', 'blue');

                % Check for convergence
                if Xf == prevXf
                    fprintf('Terminal set computation converged after %d iterations.\n', iter);
                    break;
                end

                % Check iteration limit
                if iter > max_iter
                    error('Terminal set computation did not converge within the iteration limit.');
                end
            end

            % Validate terminal set containment of the origin
            if ~Xf.contains([0; 0])
                error('Terminal set X_f does NOT contain the origin!');
            else
                fprintf('Terminal set X_f contains the origin.\n');
            end

            
            
            % Constraints and cost function
            con = [];
            obj = 0;
            
            % Initialize relative state
            % Initialize relative state
            state_init = [x0(1) - x0other(1); % Relative position (ego - lead)
                          x0(2) - x0other(2)]; % Relative velocity (ego - lead)
            con = [con, Delta_x(:, 1) == state_init];

            % Constraints over the horizon
            for i = 1:N-1
                % State dynamics
                con = [con, Delta_x(:, i+1) == mpc.A * Delta_x(:, i) - mpc.B * Delta_u(:, i)];

                % Tightened state constraints
                con = [con, X_t.A * Delta_x(:, i) <= X_t.b];

                % Tightened input constraints
                con = [con, U_t.A * Delta_u(:, i) <= U_t.b];

                % Safe distance constraint
                safe_distance = 6; % Minimum gap (meters)
                con = [con, Delta_x(1, i) >= safe_distance];  % Ensure relative distance is safe

                % Cost function
                obj = obj + (Delta_x(:, i) - x_ref)' * Q * (Delta_x(:, i) - x_ref) + ...
                            (Delta_u(:, i) - u_ref)' * R * (Delta_u(:, i) - u_ref);
            end

            % Terminal constraints
            %con = [con, X_f.A * Delta_x(:, N) <= X_f.b];  % Terminal state must lie in the terminal set

            % Terminal cost
            obj = obj + Delta_x(:, N)' * P * Delta_x(:, N); % Terminal cost using P from LQR

            % Control input applied at the first step
            con = [con, u0 == Delta_u(:, 1)];

            % Pass here YALMIP sdpvars which you want to debug. You can
            % then access them when calling your mpc controller like
            % [u, X, U] = mpc_lat.get_u(x0, ref);
            % with debugVars = {X_var, U_var};
            debugVars = {};
            
            % YOUR CODE HERE YOUR CODE HERE YOUR CODE HERE YOUR CODE HERE
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            
            % Return YALMIP optimizer object
            ctrl_opti = optimizer(con, obj, sdpsettings('solver','gurobi'), ...
                {x0, x_ref, u_ref, d_est, x0other}, {u0, debugVars{:}});
        end
        
        % Computes the steady state target which is passed to the
        % controller
        function [xs_ref, us_ref] = compute_steady_state_target(mpc, ref, d_est)

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % INPUTS
            %   ref    - reference to track
            % OUTPUTS
            %   xs_ref, us_ref - steady-state target
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            % Steady-state system
            A = mpc.A;
            B = mpc.B;

            % Linearization steady-state
            xs = mpc.xs;
            us = mpc.us;

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % YOUR CODE HERE YOUR CODE HERE YOUR CODE HERE YOUR CODE HERE
            xs_ref = [0; ref]; 
            us_ref = mpc.us + (1 - A(2,2)) / B(2) * (ref - mpc.xs(2)) - d_est; 

            % YOUR CODE HERE YOUR CODE HERE YOUR CODE HERE YOUR CODE HERE
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        end
    end
end
