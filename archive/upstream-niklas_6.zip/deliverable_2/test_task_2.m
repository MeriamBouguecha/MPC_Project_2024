car = Car(Ts); 

us = 2;
Vs = 120/3.6; 
[xs, us] = car.steady_state(Vs); 
sys = car.linearize(xs, us); 
[sys_lon, sys_lat] = car.decompose(sys); 