classdef NmpcControl < handle

    properties
        % The NMPC problem
        opti

        % Problem parameters
        x0, ref, x0other

        % Most recent problem solution
        sol

        % The input that you want to apply to the system
        u0

        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Add any variables you would like to read to debug here
        % and then store them in the NmpcControl function below.
        % e.g., you could place X here and then add obj.X = X
        % in the NmpcControl function below.
        % 
        % After solving the problem, you can then read these variables 
        % to debug via
        %   nmpc.sol.value(nmpc.X)
        % 
        X, U
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
    end

    methods
        function obj = NmpcControl(car, H)

            import casadi.*

            N_segs = ceil(H/car.Ts); % Horizon steps
            N = N_segs + 1;          % Last index in 1-based Matlab indexing

            nx = 4;
            nu = 2;

            % Define the NMPC optimization problem
            opti = casadi.Opti();
            
            % Parameters (symbolic)
            obj.x0 = opti.parameter(nx, 1);       % initial state
            obj.ref = opti.parameter(2, 1);       % target y, velocity
            obj.x0other = opti.parameter(nx, 1);  % initial state of other car

            % SET THIS VALUE TO BE YOUR CONTROL INPUT
            obj.u0 = opti.variable(nu, 1);

            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
            % YOUR CODE HERE YOUR CODE HERE YOUR CODE HERE YOUR CODE HERE
        
            % Define your problem using the opti object created above
        
            X = opti.variable(nx, N); % states over the horizon
            U = opti.variable(nu, N-1); % controls over the horizon

        
            % Dynamics function
            %f = @(x, u) [car.f(x, u)];

            % initial condition
            opti.subject_to(obj.u0 == U(:,1));
            opti.subject_to(obj.x0 == X(:,1));
        
            % Dynamics constraints
            cost = 0;

            for k = 1:N-1
                x_next = X(:,k) + car.f(X(:,k), U(:,k)); %car.Ts *
                opti.subject_to(X(:,k+1) == x_next);

                opti.subject_to(-0.5236 <= U(1,k) <= 0.5236); % steering angle
                opti.subject_to(-1 <= U(2,k) <= 1);             % motor force
                opti.subject_to(-0.5 <= X(2,k) <= 3.5);         % y
                opti.subject_to(-0.0873 <= X(3,k) <= 0.0873);

     
                cost = cost + 100*(X(2,k) - obj.ref(1))^2 + 150*(X(4,k) - obj.ref(2))^2;

                cost = cost + U(:,k)'*diag([1, 5000])*U(:,k);

                % the number 150 and 5000 has an impact on the feasability
                % of the controller and also the speed to reach the above
                % speed. However I have the impression to have an offset at
                % the beginning and i cannot reach the above limit quicker
                % ... but I don't know what is the problem hahahaha

            end
            
            opti.subject_to(-0.5 <= X(2,N) <= 3.5);         % y
            opti.subject_to(-0.0873 <= X(3,N) <= 0.0873);

            opti.minimize(cost);

            % YOUR CODE HERE YOUR CODE HERE YOUR CODE HERE YOUR CODE HERE
            %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

            % Store the defined problem to solve in get_u
            obj.opti = opti;

            % Setup solver
            options = struct;
            options.ipopt.print_level = 0;
            options.print_time = 0;
            options.expand = true;
            obj.opti.solver('ipopt', options);
        end

        function u = get_u(obj, x0, ref, x0other)

            if nargin < 4
                x0other = zeros(4, 1);
            end

            % Compute solution from x0
            obj.solve(x0(1:4), ref, x0other(1:4));

            u = obj.sol.value(obj.u0);
        end

        function solve(obj, x0, ref, x0other)

            % Pass parameter values
            obj.opti.set_value(obj.x0, x0);
            obj.opti.set_value(obj.ref, ref);
            obj.opti.set_value(obj.x0other, x0other);

            obj.sol = obj.opti.solve();   % actual solve
            
            % Set warm start for next solve
            obj.opti.set_initial(obj.sol.value_variables());
            obj.opti.set_initial(obj.opti.lam_g, obj.sol.value(obj.opti.lam_g));
        end
    end
end
