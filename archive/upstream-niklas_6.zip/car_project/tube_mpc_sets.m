function sets = tube_mpc_sets(A, B, W, filename)
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Compute the sets and parameters required for Tube MPC
    % Inputs:
    %   A, B      - Discretized system matrices
    %   W         - Disturbance set (Polytope in input space)
    %   filename  - File to save the results
    % Outputs:
    %   sets      - Struct containing K and the invariant set E
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    % Define LQR cost matrices
    Q =60*diag([1, 1]); 
    R = 0.001;

    % Compute LQR feedback gain
    [K, ~, ~] = dlqr(A, B, Q, R);
    K = -K;

    % Check stabilization of K
    A_cl = A + B * K;
    eigenvalues = eig(A_cl);
    if all(abs(eigenvalues) < 1)
        disp('The closed-loop system is stable.');
        disp(eigenvalues);
    else
        error('The closed-loop system is NOT stable. Adjust Q and R.');
    end

    % Map disturbance set W to state space: W_state = W * B
    W_vertices = W.V; % Extract vertices of W
    W_mapped_vertices = (-B * W_vertices')'; % Map vertices through B
    W_state = Polyhedron('V', W_mapped_vertices); % Create new polyhedron

    % Initialize invariant set with the mapped disturbance set
    E = W_state;

    % Iterative computation of the invariant set
    max_iter = 100;
    tolerance = 1e-2;
    A_cl_i = eye(size(A_cl)); % Initialize A_cl^i as identity matrix
    Ai_W = W_state;  
    i = 1;

    figure(1); clf; % Visualization of iterations
    hold on;
    
    %plot(E, 'color', 'b'); % Specify the color as a key-value pair

    while i <= max_iter
        prevE = E;
        A_cl_i = A_cl_i * A_cl;
        Ai_W = A_cl_i * W_state + Ai_W;
        Z = zeros(size(Ai_W.A, 1), size(prevE.A, 2)); 
        %E = projection(polytope([prevE.A -prevE.A ; Z Ai_W.A] , [prevE.b ; Ai_W.b]) , A:size(prevE.A,2)); 
        %Minkowski Sum
        NewSet = Polyhedron(...
            'A', [prevE.A, -prevE.A; Z, Ai_W.A], ...
            'b', [prevE.b; Ai_W.b] ...
        );
        E = projection(NewSet, 1:size(prevE.A, 2));
        % Plot intermediate sets
        %plot(E, 'color', 'y');
        %plot(Ai_W, 'color', 'r');
        %plot(prevE, 'color', 'g');
        
        if norm(A_cl_i, 'inf') < tolerance
            fprintf('Converged after %d iterations (norm-based stopping).\n', i);
            break;
        end
        
        %fprintf('Iteration %d: Not yet converged.\n', i);
        %pause(0.5);
        i = i + 1;
    end

    if i > max_iter
        warning('Maximum iterations reached before convergence.');
    end

    % Final visualization
    plot(E, 'color', 'k'); % Final invariant set
    legend({'Initial Set (W)', 'Intermediate Sets (yellow)', 'Accumulated Ai_W (red)', 'Previous Set (green)', 'Final Invariant Set (black)'});
    title('Computation of Minimum Robust Invariant Set');
    hold off;

    % Save results
    sets.K = K;
    sets.E = E;
    save(filename, 'sets');
end






