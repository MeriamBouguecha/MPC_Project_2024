clc; clear; close all;
%% "offline" part: 
Ts = 1/10; % Sample time (10 Hz)
H_lon = 15; % Horizon for longitudinal controller
car = Car(Ts);
[xs, us] = car.steady_state(100 / 3.6);
sys = car.linearize(xs, us);
[sys_lon, sys_lat] = car.decompose(sys); 
sys_lon_d = c2d(sys_lon, Ts); % Discretize 
[A, B, C, D] = ssdata(sys_lon_d); % Extract discrete-time matrices

M = [1;-1]; m = [us(2)+0.5; -us(2)+0.5]; %disturbance bounds 
W = Polyhedron( M, m);  

tube_mpc_sets(A ,-B, W , 'tube_mpc_data.mat');
%%
mpc_lon = MpcControl_lon(sys_lon, Ts, H_lon);
mpc_lat = MpcControl_lat(sys_lat, Ts, H_lon);
mpc = car.merge_lin_controllers(mpc_lon, mpc_lat);

%% Simulation 1
%otherRef = 100/3.6; 
% Simulation configuration for the ego car
x0 = [0 0 0 80/3.6]'; % (x, y, theta, V) 
ref1 = [0 80/3.6]'; % (y ref, V ref) 
ref2 = [3 120/3.6]'; % (y ref, V ref)
params = {};
params.Tf = 15;
params.myCar.model = car;
params.myCar.x0 = x0;
params.myCar.u = @mpc.get_u;
params.myCar.ref = car.ref_step(ref1, ref2, 5); % delay reference step by 5s 
result = simulate(params);
visualization(car, result);

%% Simulation 2
params = {};
params.Tf = 25;
params.myCar.model = car;
params.myCar.x0 =[0 0 0 115/3.6]' ;
params.myCar.u = @mpc.get_u; % Longitudinal Tube MPC controller
params.myCar.ref = 100/3.6; 
params.otherCar.model = car; % Lead car model
params.otherCar.x0 = [8 0 0 120/3.6]'; 
params.otherCar.u = car.u_fwd_ref(); 
params.otherCar.ref = car.ref_robust(); 

%%
result = simulate(params);
visualization(car, result);
